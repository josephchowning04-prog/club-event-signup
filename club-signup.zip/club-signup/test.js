// Quick check of the three examples from design.md plus search.
// Start the app first (npm start), then run: npm test
const base = process.env.BASE || 'http://localhost:3000';

async function post(body) {
  const res = await fetch(base + '/api/signups', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  return { status: res.status, data: await res.json() };
}

let failed = 0;
function check(label, actual, expected) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  console.log((ok ? 'PASS ' : 'FAIL ') + label);
  if (!ok) { failed++; console.log('  expected:', expected, '\n  got:     ', actual); }
}

(async () => {
  const t1 = await post({ name: 'Maya Chen', session: 'walk', message: '' });
  check('1. Normal signup', [t1.status, t1.data.confirmation],
    [201, "You're signed up, Maya Chen! Session: Constellation Walk (Sat 8:00 PM)."]);

  const t2 = await post({ name: '   ', session: 'moon', message: '' });
  check('2. Whitespace-only name', [t2.status, t2.data.errors], [400, { name: 'Please enter your name.' }]);

  const t3 = await post({ name: 'Maya Chen', session: 'scope', message: '' });
  check('3. Changed session', t3.data.confirmation,
    "You're signed up, Maya Chen! Session: Telescope Basics Workshop (Sun 4:00 PM).");

  const t4 = await post({ name: 'Maya Chen', session: '', message: '' });
  check('4. No session', t4.data.errors, { session: 'Please choose a session.' });

  const s = await (await fetch(base + '/api/signups?search=maya')).json();
  check('5. Search finds Maya Chen', s.results.length >= 2 && s.results[0].name === 'Maya Chen', true);

  console.log(failed ? `\n${failed} check(s) failed` : '\nAll checks passed');
  process.exit(failed ? 1 : 0);
})();
