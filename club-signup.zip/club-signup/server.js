// Harbor Lights Astronomy Club - Fall Sky Weekend signup
// No packages are needed for local use. A hosted database needs one package (pg).

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

// Read an optional .env file (simple KEY=value lines) without any package.
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith('#') && process.env[m[1]] === undefined) {
      process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
}

const PORT = Number(process.env.PORT) || 3000;

const SESSIONS = {
  moon: { title: 'Saturn and Moon Viewing', when: 'Fri 7:30 PM' },
  walk: { title: 'Constellation Walk', when: 'Sat 8:00 PM' },
  scope: { title: 'Telescope Basics Workshop', when: 'Sun 4:00 PM' },
};

// ---------- Database: hosted (if DATABASE_URL is set) or local file ----------

function escapeLike(text) {
  return text.replace(/[\\%_]/g, (c) => '\\' + c);
}

async function openDatabase() {
  if (process.env.DATABASE_URL) {
    let Pool;
    try {
      ({ Pool } = require('pg'));
    } catch {
      throw new Error(
        'DATABASE_URL is set, but the "pg" package is not installed. Run: npm install pg'
      );
    }
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
    });
    await pool.query(`CREATE TABLE IF NOT EXISTS signups (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      session TEXT NOT NULL,
      message TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`);
    return {
      kind: 'hosted database',
      async add(name, session, message) {
        await pool.query(
          'INSERT INTO signups (name, session, message) VALUES ($1, $2, $3)',
          [name, session, message]
        );
      },
      async search(text) {
        const { rows } = await pool.query(
          `SELECT name, session, message FROM signups
           WHERE name ILIKE $1 ESCAPE '\\' ORDER BY id DESC LIMIT 50`,
          ['%' + escapeLike(text) + '%']
        );
        return rows;
      },
    };
  }

  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(path.join(__dirname, 'signups.db'));
  db.exec(`CREATE TABLE IF NOT EXISTS signups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    session TEXT NOT NULL,
    message TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
  const insert = db.prepare('INSERT INTO signups (name, session, message) VALUES (?, ?, ?)');
  const find = db.prepare(
    `SELECT name, session, message FROM signups
     WHERE name LIKE ? ESCAPE '\\' ORDER BY id DESC LIMIT 50`
  );
  return {
    kind: 'local database file (signups.db)',
    async add(name, session, message) {
      insert.run(name, session, message);
    },
    async search(text) {
      return find.all('%' + escapeLike(text) + '%');
    },
  };
}

// ---------- Web server ----------

function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 10_000) {
        reject(new Error('too large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

async function start() {
  const store = await openDatabase();
  const page = fs.readFileSync(path.join(__dirname, 'public', 'index.html'));

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');

      if (req.method === 'GET' && url.pathname === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(page);
      }

      if (req.method === 'POST' && url.pathname === '/api/signups') {
        let input;
        try {
          input = JSON.parse(await readBody(req));
        } catch {
          return sendJson(res, 400, { errors: { form: 'Could not read the signup.' } });
        }
        const name = String(input.name ?? '').trim().slice(0, 60);
        const message = String(input.message ?? '').trim().slice(0, 200);
        const session = SESSIONS[input.session];
        const errors = {};
        if (!name) errors.name = 'Please enter your name.';
        if (!session) errors.session = 'Please choose a session.';
        if (Object.keys(errors).length) return sendJson(res, 400, { errors });

        await store.add(name, input.session, message);
        return sendJson(res, 201, {
          confirmation: `You're signed up, ${name}! Session: ${session.title} (${session.when}).`,
          note: message ? `Your note: ${message}` : '',
        });
      }

      if (req.method === 'GET' && url.pathname === '/api/signups') {
        const text = (url.searchParams.get('search') || '').trim().slice(0, 60);
        if (!text) return sendJson(res, 400, { error: 'Please type a name to search for.' });
        const rows = await store.search(text);
        return sendJson(res, 200, {
          results: rows.map((r) => ({
            name: r.name,
            session: SESSIONS[r.session]
              ? `${SESSIONS[r.session].title} (${SESSIONS[r.session].when})`
              : r.session,
            message: r.message,
          })),
        });
      }

      sendJson(res, 404, { error: 'Not found' });
    } catch (err) {
      console.error(err);
      sendJson(res, 500, { error: 'Something went wrong on the server. Please try again.' });
    }
  });

  server.listen(PORT, () => {
    console.log(`Signup app running at http://localhost:${PORT}`);
    console.log(`Saving signups to: ${store.kind}`);
  });
}

start().catch((err) => {
  console.error('Could not start the app:', err.message);
  process.exit(1);
});
